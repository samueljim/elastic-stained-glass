import Layout from 'layouts/Main'

export default () => <Layout>About Page</Layout>
