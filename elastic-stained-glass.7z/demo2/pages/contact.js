import Layout from 'layouts/Main'

export default () => <Layout>Contact Page</Layout>
