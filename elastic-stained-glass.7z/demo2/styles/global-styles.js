import { injectGlobal } from 'styled-components'

injectGlobal`
  ul {
    margin: 0;
    padding: 0;
  }
`
