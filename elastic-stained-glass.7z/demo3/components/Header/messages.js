import { DEFAULT_LANG } from '@/utils/constants';

const messages = {
  en: {
    hn: 'Hacker News',
  },
  vi: {
    hn: 'Hacker News',
  },
}[DEFAULT_LANG];

export default messages;
