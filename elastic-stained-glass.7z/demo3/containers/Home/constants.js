export const FETCH_DATA = 'containers/Home/FETCH_DATA';
export const FETCH_DATA_SUCCESS = 'containers/Home/FETCH_DATA_SUCCESS';
export const FETCH_DATA_FAIL = 'containers/Home/FETCH_DATA_FAIL';

export const SYNC_DATA_SERVER_CLIENT =
  'containers/Home/SYNC_DATA_SERVER_CLIENT';
