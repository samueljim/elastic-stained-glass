export default () => (
    <div className="footer">
      <style jsx global>{`
        .footer {
          background: #fff;
          font: 11px menlo;
          color: #fff;
          height:60px
        }
      `}</style>
      <p>Footer</p>
    </div>
  )
