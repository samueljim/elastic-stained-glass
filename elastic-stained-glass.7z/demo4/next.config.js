// module.exports = {
//     components: './components/**/*.js',
//     webpackConfig: {
//         module: {
//             loaders: [
//                 {
//                 test: /\.js(\?[^?]*)?$/,
//                 loader: 'babel-loader',
//                 exclude: /node_modules/,
//                 query: {
//                     cacheDirectory: true,
//                     presets: ['react'],
//                 },
//             }],
//         },
//     },
// };