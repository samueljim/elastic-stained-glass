

import Page from '../layouts/main'
export default () => (
  <Page>
    <p>my page with global styles!</p>
  </Page>
)
